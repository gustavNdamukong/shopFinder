 
            <!-- ==========================
            JS 
        =========================== -->
        <script src="http://code.jquery.com/jquery-latest.min.js"></script>
        <script src="http://code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=true"></script>
        <script src="<?php echo e(asset('js/lib/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/bootstrap-hover-dropdown.min.js')); ?>"></script><!--THIS MAKES THE MENU LINKS RESPOND TO HOVERING-->
        <script src="<?php echo e(asset('js/lib/SmoothScroll.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/jquery.dragtable.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/jquery.card.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/twitterFetcher_min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/jquery.mb.YTPlayer.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/lib/color-switcher.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
        <script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<?php /**PATH /Applications/MAMP/htdocs/laravel/shopFinder/resources/views/layouts/html_dependencies_bottom.blade.php ENDPATH**/ ?>