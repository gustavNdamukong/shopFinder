<?php

?>



<?php $__env->startSection('content'); ?>


    <style>
        ul .lon, ul .lat, ul .address, ul .postcode, ul .location
        {

        }

    </style>


    <div class="container">

        <h2 style="text-align: center;">Manage Shops</h2>


        <div class="jumbotron" id="map-canvas"></div>

        <div class="jumbotron" id="directions-canvas"></div>


        <?php //LET'S CREATE THE LOADING GIF THAT WILL BE PLACED IN THE JUMBOTRON WHEN AN AJAX CALL IS BEING MADE ?>
        <div class="loading_gif" style="display: none;">
            <img src="<?php echo e(asset('images/loading_blue.gif')); ?>" width="65" height="65" />
        </div>

        <div class="jumbotron">

            <!--<p>Geolocation</p>
            <div class="well" id="geoLocation"><small>Make sure you have location services turned on in your device. If it doesn't work at first, refresh the page and try again...</small></div>


            <div id="buttons">
                <button class="btn btn-primary" id="getGeolocation">Get your geolocation</button>
                <button class="btn btn-primary" id="getYourSpot">Get your spot on the map</button>
                <button title="Make sure you have location services turned on in your device" class="btn btn-primary" id="getDirections">Get directions to nearest shop</button>
            </div> -->

            <div class="row">

                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>List of your shops</h4>
                            <a href="<?php echo e(url('admin/create_shop')); ?>">
                                <button class="btn btn-sm btn-default">Create new shop</button>
                            </a>
                        </div>
                        <div class="panel-body">
                            <p>Showing <?php echo $shops->firstItem(); ?> to <?php echo e($shops->lastItem()); ?> of <?php echo e($shops->total()); ?> shops</p>
                            <?php if(count($shops) > 0): ?>
                            <?php for($x = 0; $x < count($shops); $x++): ?>
                            <!--<a href="<?php echo e(url('store_details/'.$shops[$x]->id)); ?>">-->
                                <div class="shop">
                                    <div class='img_container'>
                                        <div class="image">
                                            <img src="<?php echo e(empty($shops[$x]->shop_image->pluck('image_name')[0]) ?
                                                url('images/store_imgs/1.png') :
                                                url('images/store_imgs/'.$shops[$x]->shop_image->pluck('image_name')[0])); ?>" />
                                        </div>
                                    </div>
                                    <div class="shop_info">
                                        <div class="name"><?php echo e($shops[$x]->name); ?></div>
                                        <div class="description"><?php echo e($shops[$x]->description); ?></div>
                                        <div class="location"><?php echo e($shops[$x]->location); ?></div>
                                        <div class="postcode"><?php echo e($shops[$x]->postcode); ?></div>
                                        <div class="address"><?php echo e($shops[$x]->address); ?></div>
                                    </div><!--End class 'shop_info'-->
                                </div><!--End class 'shop'-->
                            <div style="margin-top:5px;">
                            <a href="<?php echo e(url("/admin/edit_shop/{$shops[$x]->id}/")); ?>">
                            <button type="button" style="height:30px;" class="btn btn-primary float-left">Edit</button>
                            </a>

                            <form action="<?php echo e(url("admin/shops/{$shops[$x]->id}/")); ?>" method="POST" id="delete_user_form">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <button id="delete_user" style="height:30px;" onclick="confirmDelete(event)" type="submit" class="btn btn-sm btn-danger float-left">Delete</button>
                            </form>
                            </div>

                            <!--</a>-->
                            <br />
                            <hr class="separate">
                            <?php endfor; ?>
                            <?php else: ?>
                                <p>You have not created any shops yet</p>
                            <?php endif; ?>

                            <div class='nav-links'>
                                <?php echo $shops->render(); ?>

                            </div>

                        </div><!--End panel body-->
                    </div><!--End panel panel-default-->
                </div><!--End of row (col-md-10)-->
            </div><!--End of row-->
        </div><!--jumbotron-->
    </div><!--End fluid body container-->
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel/shopFinder/resources/views/admin/shops/admin_shops.blade.php ENDPATH**/ ?>