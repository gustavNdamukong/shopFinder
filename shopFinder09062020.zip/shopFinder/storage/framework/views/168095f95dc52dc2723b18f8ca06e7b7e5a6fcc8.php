<?php

$imgNum = 0;
// define number of imgs per carousel slide
define('IMGS_PER_SLIDE', 4);
// initialize a counter variable for the image loop
$imgsCount = count($shopImages);

    ?>





<?php $__env->startSection('content'); ?>

        <div class="container">
    
        <h4 style="text-align: center;"><a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-primary pull-left"  role="button">Back</a> Welcome to <?php echo e($shop->pluck('name')->first()); ?> shop</h4>


        <div class="jumbotron">
            <div class="row">
                <div class="shop">
                    <div class='detail_img_container'>
                        <div class="image">
                            
                            <?php if(count($shopImages)): ?>
                                
                                <?php if($imgsCount > 1): ?>
                                    
                                    <img src="<?php echo e(asset('images/store_imgs/'.$shopImages[$imgNum])); ?>" />
                                    
                                    <div class="clearfix">
                                        <div id="thumbcarousel" class="carousel slide" data-interval="false">
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <?php $__currentLoopData = $shopImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div data-target="#carousel" data-slide-to="<?php echo e($imgNum); ?>" class="thumb col-sm-3">
                                                        <!--######## click on the thumbs n view them bigger in a cool BS img gallery##################-->
                                                        <a href="<?php echo e(asset('images/store_imgs/'.$image)); ?>"
                                                           class='thumbnail img-responsive' data-gallery>
                                                            <img src="<?php echo e(asset('images/store_imgs/'.$image)); ?>"
                                                                 width='100' height='100'
                                                                 style="overflow:hidden;"/>
                                                        </a>
                                                    </div>
                                                    <?php //increment the count of imgs on the slide
                                                    $imgNum++; ?>

                                                    
                                                    <?php if(($imgNum % IMGS_PER_SLIDE === 0) && ($imgNum < $imgsCount)): ?>
                                                </div><!--end the 'item active' div wh contains the max number of visible images per slide. Clicking the arrow will move to the next slide
                                                    So if we've displayed the max num of img in the slide, we close the slide (item active) div here and open another one wh has no active class.
                                                    Only the slide (div) with the active class will be displayed at any one time. Clicking to move to the next slide will transfer the 'active'
                                                    class to the next div (slide) which will make that next div become visible (active).-->
                                                        <!-- start the item div -->
                                                <div class="item">
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                </div><!--This could be the end of either the div with the 'item' class or the 'item active' div. Note this is b/c if the total imgs were more
                                                    than the max num required to be displayed in one slide (as checked for in the if statement above), this closing div will be closing the
                                                    'item' div that would have been started, otherwise it will be closing the 'item active' div that was started to contain the thumbnail imgs.
                                                    Remember that whether the 'item' div was started or not, the loop above will insert the 'thumb' divs (imgs) into which ever div is open. -->
                                            </div><!-- / end carousel-inner -->
                                            <a class="left carousel-control" href="#thumbcarousel" role="button"
                                               data-slide="prev">
                                                <span class="glyphicon glyphicon-chevron-left"></span>
                                            </a>
                                            <a class="right carousel-control" href="#thumbcarousel" role="button"
                                               data-slide="next">
                                                <span class="glyphicon glyphicon-chevron-right"></span>
                                            </a>
                                        </div> <!-- /thumbcarousel-->
                                    </div><!-- /clearfix -->

                                <?php elseif($imgsCount === 1): ?> 
                                    <img src="<?php echo e(asset('images/store_imgs/'.$shopImages[0])); ?>" />
                                <?php endif; ?> 
                            <?php elseif($imgsCount < 1): ?> 
                                <img src="<?php echo e(asset('images/store_imgs/1.png')); ?>" />
                            <?php endif; ?> 
                        </div>
                    </div>
                    <div class="shop_info">
                        <div class="name"><p><b>Name:</b> <?php echo e($shop->pluck('name')[0]); ?></p></div>
                        <div class="location"><b>Location:</b>  <?php echo e($shop->pluck('city')[0]); ?></div>
                        <div class="address"><b>Address:</b><br />  <?php echo e($shop->pluck('address')[0]); ?></div>
                    </div><!--End class 'resto_info'-->
                    <div class="description">
                        <b>Description:</b>
                        <?php echo e($shop->pluck('description')[0]); ?>


                    <a href="#">
                        <span id="favBtn" onclick="alert('Add to favourites feature coming soon :)')" style="font-size: 50px;color:gold;" class="glyphicon glyphicon-heart pull-right" title="Add to your favourites"></span>
                    </a>
                    </div>

                </div><!--End class 'resto'-->
            </div><!--End of row-->
        </div><!--jumbotron-->
    </div><!--End of (body) container-->

    <?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel/shopFinder/resources/views/shop_details.blade.php ENDPATH**/ ?>